Problem Statement:
Find starship and slime torpedo patterns in the given data.

Approach:
Consider given test data as a big 2D array of zero's and one's (zero for space (off), one for + (on)).

The starship and slime torpedo are small 2D arrays.

We have findout how many times the small 2D arrays occur in the given big 2d array.

Assumptions:
My program assumes exact match for the small 2d array.

Result:
Program results zero occurence of starship or slime torpedo as there are no exact matches.

Steps to run:
Unzip the attached zip to C:\\nextstepforservicenow
I have converted .blf files to .txt in the same dir.
Run the attached .class file like "java TestPrg"
